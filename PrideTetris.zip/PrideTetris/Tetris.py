import pygame
import random
import sys
import webbrowser

# Initialize Pygame
pygame.init()

# Constants
GRID_WIDTH = 10
GRID_HEIGHT = 20
CELL_SIZE = 30
GRID_X_OFFSET = 50
GRID_Y_OFFSET = 50
WINDOW_WIDTH = GRID_WIDTH * CELL_SIZE + 2 * GRID_X_OFFSET + 200
WINDOW_HEIGHT = GRID_HEIGHT * CELL_SIZE + 2 * GRID_Y_OFFSET

# Pride flag color schemes for each tetromino
PRIDE_COLORS = {
    'I': [(228, 3, 3), (255, 140, 0), (255, 237, 0), (0, 128, 38), (0, 77, 255), (117, 7, 135)],  # Rainbow Pride: Red, Orange, Yellow, Green, Blue, Purple
    'O': [(213, 45, 0), (255, 154, 86), (255, 255, 255), (211, 98, 164)],  # Lesbian flag: Dark Orange, Light Orange, White, Pink
    'T': [(91, 206, 250), (245, 169, 184), (255, 255, 255), (245, 169, 184), (91, 206, 250)],  # Trans flag: Light Blue, Pink, White, Pink, Light Blue
    'S': [(214, 2, 112), (155, 79, 150), (0, 56, 168)],  # Bi flag: Magenta, Purple, Blue
    'Z': [(255, 244, 48), (255, 255, 255), (156, 89, 209), (0, 0, 0)],  # Non-binary flag: Yellow, White, Purple, Black
    'J': [(61, 165, 66), (167, 211, 121), (255, 255, 255), (169, 169, 169), (0, 0, 0)],  # Aromantic flag: Green, Light Green, White, Gray, Black
    'L': [(0, 0, 0), (164, 164, 164), (255, 255, 255), (128, 0, 128)]  # Asexual flag: Black, Gray, White, Purple
}

BLACK = (0, 0, 0)
BROWN = (101, 67, 33)  # Brown background color
WHITE = (255, 255, 255)
GRAY = (128, 128, 128)
DARK_BLUE = (26, 26, 46)
PRIDE_RAINBOW = [(228, 3, 3), (255, 140, 0), (255, 237, 0), (0, 128, 38), (0, 77, 255), (117, 7, 135)]

# Game states
TITLE_SCREEN = 0
PLAYING = 1
GAME_OVER = 2

# Tetromino shapes
SHAPES = {
    'I': [['.....',
           '..#..',
           '..#..',
           '..#..',
           '..#..'],
          ['.....',
           '.....',
           '####.',
           '.....',
           '.....']],
    
    'O': [['.....',
           '.....',
           '.##..',
           '.##..',
           '.....']],
    
    'T': [['.....',
           '.....',
           '.#...',
           '###..',
           '.....'],
          ['.....',
           '.....',
           '.#...',
           '.##..',
           '.#...'],
          ['.....',
           '.....',
           '.....',
           '###..',
           '.#...'],
          ['.....',
           '.....',
           '.#...',
           '##...',
           '.#...']],
    
    'S': [['.....',
           '.....',
           '.##..',
           '##...',
           '.....'],
          ['.....',
           '.#...',
           '.##..',
           '..#..',
           '.....']],
    
    'Z': [['.....',
           '.....',
           '##...',
           '.##..',
           '.....'],
          ['.....',
           '..#..',
           '.##..',
           '.#...',
           '.....']],
    
    'J': [['.....',
           '.#...',
           '.#...',
           '##...',
           '.....'],
          ['.....',
           '.....',
           '#....',
           '###..',
           '.....'],
          ['.....',
           '.##..',
           '.#...',
           '.#...',
           '.....'],
          ['.....',
           '.....',
           '###..',
           '..#..',
           '.....']],
    
    'L': [['.....',
           '..#..',
           '..#..',
           '.##..',
           '.....'],
          ['.....',
           '.....',
           '###..',
           '#....',
           '.....'],
          ['.....',
           '##...',
           '.#...',
           '.#...',
           '.....'],
          ['.....',
           '.....',
           '..#..',
           '###..',
           '.....']]
}

class FallingBlock:
    def __init__(self):
        self.x = random.randint(0, WINDOW_WIDTH)
        self.y = -20
        self.color = random.choice(PRIDE_RAINBOW)
        self.speed = random.uniform(1, 3)
        self.size = random.randint(8, 15)
    
    def update(self):
        self.y += self.speed
    
    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.size, self.size))
        pygame.draw.rect(screen, WHITE, (self.x, self.y, self.size, self.size), 1)

class Tetromino:
    def __init__(self, shape):
        self.shape = shape
        self.colors = PRIDE_COLORS[shape]
        self.x = GRID_WIDTH // 2 - 2
        self.y = 0
        self.rotation = 0
    
    def get_rotated_shape(self):
        return SHAPES[self.shape][self.rotation % len(SHAPES[self.shape])]
    
    def get_cell_colors(self, cell_index):
        # For bisected squares, we need to return multiple colors
        colors = self.colors
        num_colors = len(colors)
        
        if num_colors <= 4:
            # If 4 or fewer colors, each square shows 2 colors (top/bottom)
            color1_idx = (cell_index * 2) % num_colors
            color2_idx = (cell_index * 2 + 1) % num_colors
            return colors[color1_idx], colors[color2_idx]
        else:
            # If more than 4 colors, distribute them across squares
            colors_per_square = max(2, num_colors // 4)
            start_idx = (cell_index * colors_per_square) % num_colors
            color1 = colors[start_idx]
            color2 = colors[(start_idx + 1) % num_colors]
            return color1, color2

def draw_bisected_square(screen, rect, color1, color2, border_color=WHITE):
    """Draw a square bisected diagonally with two colors"""
    # Create triangle points for diagonal bisection
    top_left = (rect.left, rect.top)
    top_right = (rect.right, rect.top)
    bottom_left = (rect.left, rect.bottom)
    bottom_right = (rect.right, rect.bottom)
    
    # Draw top-left triangle
    pygame.draw.polygon(screen, color1, [top_left, top_right, bottom_left])
    
    # Draw bottom-right triangle
    pygame.draw.polygon(screen, color2, [top_right, bottom_right, bottom_left])
    
    # Draw border
    pygame.draw.rect(screen, border_color, rect, 1)

def draw_gradient_text(screen, text, font, colors, x, y):
    """Draw text with rainbow gradient effect"""
    text_surface = font.render(text, True, WHITE)
    text_rect = text_surface.get_rect()
    
    # Create a surface for the gradient text
    gradient_surface = pygame.Surface(text_rect.size, pygame.SRCALPHA)
    
    # Draw the text multiple times with different colors
    char_width = text_rect.width // len(text) if len(text) > 0 else 0
    for i, char in enumerate(text):
        color_index = i % len(colors)
        char_surface = font.render(char, True, colors[color_index])
        gradient_surface.blit(char_surface, (i * char_width, 0))
    
    screen.blit(gradient_surface, (x, y))
    return text_rect

class TitleScreen:
    def __init__(self):
        self.falling_blocks = []
        self.time = 0
        self.pulse_alpha = 255
        self.pulse_direction = -2
        
        # Create initial falling blocks
        for _ in range(15):
            block = FallingBlock()
            block.y = random.randint(-WINDOW_HEIGHT, 0)
            self.falling_blocks.append(block)
    
    def update(self, dt):
        self.time += dt
        
        # Update falling blocks
        for block in self.falling_blocks[:]:
            block.update()
            if block.y > WINDOW_HEIGHT:
                self.falling_blocks.remove(block)
        
        # Add new falling blocks
        if random.random() < 0.1:
            self.falling_blocks.append(FallingBlock())
        
        # Update pulse effect
        self.pulse_alpha += self.pulse_direction
        if self.pulse_alpha <= 100:
            self.pulse_direction = 2
        elif self.pulse_alpha >= 255:
            self.pulse_direction = -2
    
    def draw(self, screen):
        # Draw background gradient
        for y in range(WINDOW_HEIGHT):
            color_ratio = y / WINDOW_HEIGHT
            r = int(26 + (16 - 26) * color_ratio)
            g = int(26 + (33 - 26) * color_ratio)
            b = int(46 + (96 - 46) * color_ratio)
            pygame.draw.line(screen, (r, g, b), (0, y), (WINDOW_WIDTH, y))
        
        # Draw falling blocks
        for block in self.falling_blocks:
            block.draw(screen)
        
        # Draw title
        title_font = pygame.font.Font(None, 72)
        subtitle_font = pygame.font.Font(None, 32)
        instruction_font = pygame.font.Font(None, 48)
        info_font = pygame.font.Font(None, 24)
        small_font = pygame.font.Font(None, 20)
        
        # Main title with rainbow effect
        title_y = WINDOW_HEIGHT // 6
        draw_gradient_text(screen, "PRIDE TETRIS", title_font, PRIDE_RAINBOW, 
                          WINDOW_WIDTH // 2 - title_font.size("PRIDE TETRIS")[0] // 2, title_y)
        
        # Subtitle
        subtitle_text = subtitle_font.render("Celebrate Love, Diversity & Unity", True, WHITE)
        subtitle_rect = subtitle_text.get_rect(center=(WINDOW_WIDTH // 2, title_y + 100))
        screen.blit(subtitle_text, subtitle_rect)
        
        # Animated tetris blocks
        block_y = title_y + 150
        block_size = 25
        block_spacing = 35
        start_x = WINDOW_WIDTH // 2 - (5 * block_spacing) // 2
        
        for i in range(5):
            x = start_x + i * block_spacing
            float_offset = int(10 * pygame.math.Vector2(0, 1).rotate(self.time * 0.1 + i * 72).y)
            color1 = PRIDE_RAINBOW[i]
            color2 = PRIDE_RAINBOW[(i + 1) % len(PRIDE_RAINBOW)]
            rect = pygame.Rect(x, block_y + float_offset, block_size, block_size)
            draw_bisected_square(screen, rect, color1, color2, WHITE)
        
        # Pulsing instruction text
        instruction_surface = instruction_font.render("Press ENTER to Play", True, WHITE)
        instruction_surface.set_alpha(self.pulse_alpha)
        instruction_rect = instruction_surface.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2))
        screen.blit(instruction_surface, instruction_rect)
        
        # Controls
        controls = [
            "Game Controls:",
            "Arrow Keys: Move & Rotate",
            "Space: Hard Drop",
            "ESC: Exit Anytime"
        ]
        
        controls_y = WINDOW_HEIGHT // 2 + 80
        for i, control in enumerate(controls):
            color = WHITE if i == 0 else GRAY
            font = info_font if i == 0 else small_font
            text = font.render(control, True, color)
            text_rect = text.get_rect(center=(WINDOW_WIDTH // 2, controls_y + i * 25))
            screen.blit(text, text_rect)
        
        # Pride flags info
        flags_text = small_font.render("Featured Pride Flags:", True, WHITE)
        flags_rect = flags_text.get_rect(center=(WINDOW_WIDTH // 2, controls_y + 120))
        screen.blit(flags_text, flags_rect)
        
        flags_list = small_font.render("Rainbow • Lesbian • Transgender • Bisexual • Non-binary • Aromantic • Asexual", True, GRAY)
        flags_list_rect = flags_list.get_rect(center=(WINDOW_WIDTH // 2, controls_y + 145))
        screen.blit(flags_list, flags_list_rect)
        
        # Trevor Project donation link
        donate_text = info_font.render("💝 Press D to Donate to The Trevor Project", True, (255, 107, 107))
        donate_rect = donate_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT - 60))
        screen.blit(donate_text, donate_rect)
        
        # Credit
        credit_text = small_font.render("Brought to you by Icey Hardrada", True, (136, 136, 136))
        credit_rect = credit_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT - 30))
        screen.blit(credit_text, credit_rect)

class TetrisGame:
    def __init__(self):
        self.grid = [[BROWN for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]
        self.grid_colors = [[(BROWN, BROWN) for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]
        self.current_piece = self.get_new_piece()
        self.next_piece = self.get_new_piece()
        self.score = 0
        self.level = 1
        self.lines_cleared = 0
        self.fall_time = 0
        self.fall_speed = 500  # milliseconds
        
    def get_new_piece(self):
        return Tetromino(random.choice(list(SHAPES.keys())))
    
    def is_valid_position(self, piece, dx=0, dy=0, rotation=None):
        if rotation is None:
            rotation = piece.rotation
        
        shape = SHAPES[piece.shape][rotation % len(SHAPES[piece.shape])]
        
        for y, row in enumerate(shape):
            for x, cell in enumerate(row):
                if cell == '#':
                    new_x = piece.x + x + dx
                    new_y = piece.y + y + dy
                    
                    if (new_x < 0 or new_x >= GRID_WIDTH or 
                        new_y >= GRID_HEIGHT or
                        (new_y >= 0 and self.grid[new_y][new_x] != BROWN)):
                        return False
        return True
    
    def place_piece(self, piece):
        shape = piece.get_rotated_shape()
        cell_index = 0
        for y, row in enumerate(shape):
            for x, cell in enumerate(row):
                if cell == '#':
                    grid_x = piece.x + x
                    grid_y = piece.y + y
                    if 0 <= grid_x < GRID_WIDTH and 0 <= grid_y < GRID_HEIGHT:
                        self.grid[grid_y][grid_x] = WHITE  # Mark as occupied
                        color1, color2 = piece.get_cell_colors(cell_index)
                        self.grid_colors[grid_y][grid_x] = (color1, color2)
                        cell_index += 1
    
    def clear_lines(self):
        lines_to_clear = []
        for y in range(GRID_HEIGHT):
            if all(cell != BROWN for cell in self.grid[y]):
                lines_to_clear.append(y)
        
        for y in lines_to_clear:
            del self.grid[y]
            del self.grid_colors[y]
            self.grid.insert(0, [BROWN for _ in range(GRID_WIDTH)])
            self.grid_colors.insert(0, [(BROWN, BROWN) for _ in range(GRID_WIDTH)])
        
        lines_cleared = len(lines_to_clear)
        self.lines_cleared += lines_cleared
        self.score += lines_cleared * 100 * self.level
        self.level = self.lines_cleared // 10 + 1
        self.fall_speed = max(50, 500 - (self.level - 1) * 50)
    
    def move_piece(self, dx, dy):
        if self.is_valid_position(self.current_piece, dx, dy):
            self.current_piece.x += dx
            self.current_piece.y += dy
            return True
        return False
    
    def rotate_piece(self):
        new_rotation = (self.current_piece.rotation + 1) % len(SHAPES[self.current_piece.shape])
        if self.is_valid_position(self.current_piece, rotation=new_rotation):
            self.current_piece.rotation = new_rotation
    
    def drop_piece(self):
        while self.move_piece(0, 1):
            self.score += 1
    
    def update(self, dt):
        self.fall_time += dt
        if self.fall_time >= self.fall_speed:
            if not self.move_piece(0, 1):
                self.place_piece(self.current_piece)
                self.clear_lines()
                self.current_piece = self.next_piece
                self.next_piece = self.get_new_piece()
                
                if not self.is_valid_position(self.current_piece):
                    return False  # Game over
            self.fall_time = 0
        return True
    
    def draw(self, screen):
        # Draw placed pieces on grid
        for y in range(GRID_HEIGHT):
            for x in range(GRID_WIDTH):
                rect = pygame.Rect(
                    GRID_X_OFFSET + x * CELL_SIZE,
                    GRID_Y_OFFSET + y * CELL_SIZE,
                    CELL_SIZE,
                    CELL_SIZE
                )
                if self.grid[y][x] != BROWN:
                    color1, color2 = self.grid_colors[y][x]
                    draw_bisected_square(screen, rect, color1, color2, WHITE)
                else:
                    pygame.draw.rect(screen, BROWN, rect)
                    pygame.draw.rect(screen, WHITE, rect, 1)
        
        # Draw current piece
        if self.current_piece:
            shape = self.current_piece.get_rotated_shape()
            cell_index = 0
            for y, row in enumerate(shape):
                for x, cell in enumerate(row):
                    if cell == '#':
                        rect = pygame.Rect(
                            GRID_X_OFFSET + (self.current_piece.x + x) * CELL_SIZE,
                            GRID_Y_OFFSET + (self.current_piece.y + y) * CELL_SIZE,
                            CELL_SIZE,
                            CELL_SIZE
                        )
                        color1, color2 = self.current_piece.get_cell_colors(cell_index)
                        draw_bisected_square(screen, rect, color1, color2, WHITE)
                        cell_index += 1
        
        # Draw next piece preview
        font = pygame.font.Font(None, 36)
        text = font.render("Next:", True, WHITE)
        screen.blit(text, (GRID_X_OFFSET + GRID_WIDTH * CELL_SIZE + 20, GRID_Y_OFFSET))
        
        if self.next_piece:
            shape = self.next_piece.get_rotated_shape()
            cell_index = 0
            for y, row in enumerate(shape):
                for x, cell in enumerate(row):
                    if cell == '#':
                        rect = pygame.Rect(
                            GRID_X_OFFSET + GRID_WIDTH * CELL_SIZE + 20 + x * 20,
                            GRID_Y_OFFSET + 50 + y * 20,
                            20,
                            20
                        )
                        color1, color2 = self.next_piece.get_cell_colors(cell_index)
                        draw_bisected_square(screen, rect, color1, color2, WHITE)
                        cell_index += 1
        
        # Draw score and level
        score_text = font.render(f"Score: {self.score}", True, WHITE)
        level_text = font.render(f"Level: {self.level}", True, WHITE)
        lines_text = font.render(f"Lines: {self.lines_cleared}", True, WHITE)
        
        screen.blit(score_text, (GRID_X_OFFSET + GRID_WIDTH * CELL_SIZE + 20, GRID_Y_OFFSET + 200))
        screen.blit(level_text, (GRID_X_OFFSET + GRID_WIDTH * CELL_SIZE + 20, GRID_Y_OFFSET + 240))
        screen.blit(lines_text, (GRID_X_OFFSET + GRID_WIDTH * CELL_SIZE + 20, GRID_Y_OFFSET + 280))
        
        # Draw pride flag legend
        legend_font = pygame.font.Font(None, 20)
        legend_y = GRID_Y_OFFSET + 320
        
        pride_flags = {
            'I': "Rainbow Pride (6 colors)",
            'O': "Lesbian (4 colors)",
            'T': "Transgender (5 colors)", 
            'S': "Bisexual (3 colors)",
            'Z': "Non-binary (4 colors)",
            'J': "Aromantic (5 colors)",
            'L': "Asexual (4 colors)"
        }
        
        legend_text = legend_font.render("Pride Flags:", True, WHITE)
        screen.blit(legend_text, (GRID_X_OFFSET + GRID_WIDTH * CELL_SIZE + 20, legend_y))
        
        for i, (shape, flag_name) in enumerate(pride_flags.items()):
            y_pos = legend_y + 25 + i * 20
            flag_text = legend_font.render(f"{shape}: {flag_name}", True, GRAY)
            screen.blit(flag_text, (GRID_X_OFFSET + GRID_WIDTH * CELL_SIZE + 20, y_pos))
        
        # Draw controls
        controls_font = pygame.font.Font(None, 24)
        controls = [
            "Controls:",
            "Left/Right Move",
            "Down Soft drop",
            "Up Rotate",
            "Space Hard drop",
            "ESC Exit"
        ]
        
        controls_start_y = legend_y + 180
        for i, control in enumerate(controls):
            color = WHITE if i == 0 else GRAY
            text = controls_font.render(control, True, color)
            screen.blit(text, (GRID_X_OFFSET + GRID_WIDTH * CELL_SIZE + 20, controls_start_y + i * 25))

def main():
    """
    Pride Tetris Game
    
    A celebration of love, diversity, and unity through the classic game of Tetris.
    Each tetromino piece features colors from different Pride flags, creating beautiful
    patterns as you play. This game is brought to you by Icey Hardrada.
    
    Support LGBTQ+ youth by donating to The Trevor Project: https://www.thetrevorproject.org/donate/
    """
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption("Pride Tetris - Brought to you by Icey Hardrada")
    clock = pygame.time.Clock()
    
    # Game state management
    game_state = TITLE_SCREEN
    title_screen = TitleScreen()
    game = None
    
    while True:
        dt = clock.tick(60)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    # ESC exits the game at any time
                    pygame.quit()
                    sys.exit()
                
                if game_state == TITLE_SCREEN:
                    if event.key == pygame.K_RETURN:
                        # Start the game
                        game = TetrisGame()
                        game_state = PLAYING
                    elif event.key == pygame.K_d:
                        # Open Trevor Project donation page
                        try:
                            webbrowser.open("https://www.thetrevorproject.org/donate/")
                        except:
                            print("Could not open web browser. Please visit: https://www.thetrevorproject.org/donate/")
                
                elif game_state == PLAYING:
                    if event.key == pygame.K_r:
                        game = TetrisGame()
                    elif event.key == pygame.K_LEFT:
                        game.move_piece(-1, 0)
                    elif event.key == pygame.K_RIGHT:
                        game.move_piece(1, 0)
                    elif event.key == pygame.K_DOWN:
                        game.move_piece(0, 1)
                    elif event.key == pygame.K_UP:
                        game.rotate_piece()
                    elif event.key == pygame.K_SPACE:
                        game.drop_piece()
                
                elif game_state == GAME_OVER:
                    if event.key == pygame.K_r:
                        game = TetrisGame()
                        game_state = PLAYING
                    elif event.key == pygame.K_RETURN:
                        game_state = TITLE_SCREEN
        
        # Update game state
        if game_state == TITLE_SCREEN:
            title_screen.update(dt)
        elif game_state == PLAYING:
            if not game.update(dt):
                game_state = GAME_OVER
        
        # Draw everything
        screen.fill(BLACK)
        
        if game_state == TITLE_SCREEN:
            title_screen.draw(screen)
        elif game_state == PLAYING:
            game.draw(screen)
        elif game_state == GAME_OVER:
            game.draw(screen)
            
            # Draw game over overlay
            overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
            overlay.set_alpha(128)
            overlay.fill(BLACK)
            screen.blit(overlay, (0, 0))
            
            font = pygame.font.Font(None, 72)
            game_over_text = font.render("GAME OVER", True, WHITE)
            restart_text = pygame.font.Font(None, 36).render("Press R to restart or ENTER for title", True, WHITE)
            
            text_rect = game_over_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2))
            restart_rect = restart_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 + 50))
            
            screen.blit(game_over_text, text_rect)
            screen.blit(restart_text, restart_rect)
        
        pygame.display.flip()

if __name__ == "__main__":
    main()